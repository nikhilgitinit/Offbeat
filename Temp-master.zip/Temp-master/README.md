# Sample React repository

### To GET data from an API 
### To render in a react application

### URL: https://backend.offbeat.today/news-v2/?format=json
